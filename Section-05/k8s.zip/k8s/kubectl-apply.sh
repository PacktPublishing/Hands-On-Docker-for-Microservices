#!/usr/bin/env sh
# Files are ordered in proper order with needed wait for the dependent custom resource definitions to get initialized.
# Usage: sh ../apply.sh
kubectl apply -f ../k8s/registry/
kubectl apply -f ../k8s/invoiceapp/
kubectl apply -f ../k8s/storeapp/
